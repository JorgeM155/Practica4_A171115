<?php
require_once "lib/nusoap.php";
function getEstados($datos){
    if($datos == "Deportes"){
        return join(",",array(
            "Futbol",
            "Basquetbol",
            "Voleybol",
            "baseball"
        ));
    }
    else {
        return "No hay deportes";
    }
}
$server = new soap_server();
$server->register("getEstados");
if( lisset( $HTTP_RAW_POST_DATA ) ) $HTTP_RAW_POST_DATA =file_get_contents( 'php://input' );
    $server->service($HTTP_RAW_POST_DATA);
?>
